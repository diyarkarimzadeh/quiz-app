import React from "react";
import QuestionCard from "../components/QuestionCard";

const Question4 = () => {
  return (
    <div>
      <QuestionCard index={3} />
    </div>
  );
};

export default Question4;
