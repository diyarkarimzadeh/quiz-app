import React from "react";
import QuestionCard from "../components/QuestionCard";

const Question1 = () => {
  return (
    <div>
      <QuestionCard index={0} />
    </div>
  );
};

export default Question1;
