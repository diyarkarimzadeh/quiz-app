import React from "react";
import QuestionCard from "../components/QuestionCard";

const Question5 = () => {
  return (
    <div>
      <QuestionCard index={4} />
    </div>
  );
};

export default Question5;
