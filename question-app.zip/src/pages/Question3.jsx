import React from "react";
import QuestionCard from "../components/QuestionCard";

const Question3 = () => {
  return (
    <div>
      <QuestionCard index={2} />
    </div>
  );
};

export default Question3;
