import React from "react";
import QuestionCard from "../components/QuestionCard";

const Question2 = () => {
  return (
    <div>
      <QuestionCard index={1} />
    </div>
  );
};

export default Question2;
